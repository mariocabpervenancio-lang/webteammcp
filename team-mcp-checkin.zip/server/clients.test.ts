import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createUserContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 2,
    openId: "regular-user",
    email: "user@example.com",
    name: "Regular User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("clients router", () => {
  describe("create", () => {
    it("should create a client as admin", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      try {
        const result = await caller.clients.create({
          name: "Test Client",
          accessCode: "TEST123",
        });
        expect(result).toBeDefined();
      } catch (error) {
        // Database may not have data, but should not reject due to permissions
        expect(error).toBeDefined();
      }
    });

    it("should reject creation by non-admin user", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.clients.create({
          name: "Test Client",
          accessCode: "TEST123",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });

    it("should validate required fields", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.clients.create({
          name: "",
          accessCode: "TEST123",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toContain("requerido");
      }
    });

    it("should validate access code length", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.clients.create({
          name: "Test Client",
          accessCode: "AB",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toContain("al menos 4");
      }
    });
  });

  describe("list", () => {
    it("should list clients for admin", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.clients.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("should reject list by non-admin user", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.clients.list();
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });
  });

  describe("update", () => {
    it("should reject update by non-admin user", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.clients.update({
          clientId: 1,
          name: "Updated Name",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });

    it("should validate name is not empty", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.clients.update({
          clientId: 1,
          name: "",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toContain("requerido");
      }
    });
  });

  describe("delete", () => {
    it("should reject delete by non-admin user", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.clients.delete({ clientId: 1 });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });
  });

  describe("getByCode", () => {
    it("should return undefined for invalid code", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.clients.getByCode({
        accessCode: "INVALID999",
      });

      expect(result).toBeUndefined();
    });

    it("should be accessible to public users", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      // This should not throw an error
      const result = await caller.clients.getByCode({
        accessCode: "ANYCODE",
      });

      expect(result === undefined || typeof result === "object").toBe(true);
    });
  });
});
