import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, clients, checkIns, photos, Client, InsertClient, CheckIn, InsertCheckIn, Photo, InsertPhoto } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ CLIENTS ============

export async function createClient(trainerId: number, name: string, accessCode: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(clients).values({
    trainerId,
    name,
    accessCode,
  });

  return result;
}

export async function getClientByAccessCode(accessCode: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(clients)
    .where(eq(clients.accessCode, accessCode))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getClientsByTrainerId(trainerId: number) {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(clients).where(eq(clients.trainerId, trainerId));
}

export async function updateClient(clientId: number, name: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .update(clients)
    .set({ name, updatedAt: new Date() })
    .where(eq(clients.id, clientId));
}

export async function deleteClient(clientId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.delete(clients).where(eq(clients.id, clientId));
}

// ============ CHECK-INS ============

export async function createCheckIn(
  clientId: number,
  responses: Record<string, any>,
  comments: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(checkIns).values({
    clientId,
    responses: JSON.stringify(responses),
    comments: comments || null,
  });

  return result;
}

export async function getCheckInsByClientId(clientId: number) {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(checkIns).where(eq(checkIns.clientId, clientId));
}

export async function getCheckInById(checkInId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(checkIns).where(eq(checkIns.id, checkInId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ PHOTOS ============

export async function createPhoto(checkInId: number, storageKey: string, url: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(photos).values({
    checkInId,
    storageKey,
    url,
  });
}

export async function getPhotosByCheckInId(checkInId: number) {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(photos).where(eq(photos.checkInId, checkInId));
}

// TODO: add feature queries here as your schema grows.
