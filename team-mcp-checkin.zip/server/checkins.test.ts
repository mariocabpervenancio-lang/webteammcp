import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("checkIns router", () => {
  describe("create", () => {
    it("should reject check-in with invalid access code", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.checkIns.create({
          clientId: 1,
          accessCode: "INVALID",
          responses: {
            energy: 5,
            fatigue: 3,
            training: 7,
            intensity: 6,
            mindMuscle: 8,
            hunger: 4,
            hydration: 9,
            sleep: 6,
            motivation: 7,
            progress: 8,
          },
          comments: "Test comment",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });

    it("should reject check-in with mismatched client ID", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.checkIns.create({
          clientId: 999,
          accessCode: "VALIDCODE",
          responses: {
            energy: 5,
            fatigue: 3,
            training: 7,
            intensity: 6,
            mindMuscle: 8,
            hunger: 4,
            hydration: 9,
            sleep: 6,
            motivation: 7,
            progress: 8,
          },
          comments: "Test comment",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });

    it("should validate responses are numbers", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.checkIns.create({
          clientId: 1,
          accessCode: "VALIDCODE",
          responses: {
            energy: "not a number" as any,
          },
          comments: "Test",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toBeDefined();
      }
    });
  });

  describe("listByClient", () => {
    it("should reject list by non-admin user", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.checkIns.listByClient({ clientId: 1 });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });

    it("should list check-ins for admin", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.checkIns.listByClient({ clientId: 1 });
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("getDetail", () => {
    it("should reject detail by non-admin user", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.checkIns.getDetail({ checkInId: 1 });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });

    it("should return null for non-existent check-in", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.checkIns.getDetail({ checkInId: 99999 });
      expect(result).toBeNull();
    });
  });
});

describe("photos router", () => {
  describe("upload", () => {
    it("should reject upload with invalid access code", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.photos.upload({
          checkInId: 1,
          fileName: "test.jpg",
          fileData: "base64data",
          accessCode: "INVALID",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });

    it("should reject files larger than 5MB", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      // Create a large base64 string (> 5MB when decoded)
      const largeBuffer = Buffer.alloc(6 * 1024 * 1024);
      const largeData = largeBuffer.toString('base64');

      try {
        await caller.photos.upload({
          checkInId: 1,
          fileName: "large.jpg",
          fileData: largeData,
          accessCode: "VALIDCODE",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        // Should throw an error (either for invalid code or file size)
        expect(error).toBeDefined();
        expect(error.code).toBeDefined();
      }
    });
  });

  describe("listByCheckIn", () => {
    it("should reject list by non-admin user", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.photos.listByCheckIn({ checkInId: 1 });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });

    it("should list photos for admin", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.photos.listByCheckIn({ checkInId: 1 });
      expect(Array.isArray(result)).toBe(true);
    });
  });
});
