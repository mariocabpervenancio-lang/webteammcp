import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  createClient,
  getClientByAccessCode,
  getClientsByTrainerId,
  updateClient,
  deleteClient,
  createCheckIn,
  getCheckInsByClientId,
  getCheckInById,
  createPhoto,
  getPhotosByCheckInId,
} from "./db";
import { storagePut } from "./storage";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  clients: router({
    // Create a new client (admin only)
    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1, "El nombre es requerido"),
          accessCode: z.string().min(4, "El código debe tener al menos 4 caracteres"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return createClient(ctx.user.id, input.name, input.accessCode);
      }),

    // Get all clients for the trainer (admin only)
    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return getClientsByTrainerId(ctx.user.id);
    }),

    // Update client name (admin only)
    update: protectedProcedure
      .input(
        z.object({
          clientId: z.number(),
          name: z.string().min(1, "El nombre es requerido"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return updateClient(input.clientId, input.name);
      }),

    // Delete a client (admin only)
    delete: protectedProcedure
      .input(z.object({ clientId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return deleteClient(input.clientId);
      }),

    // Get client by access code (public)
    getByCode: publicProcedure
      .input(z.object({ accessCode: z.string() }))
      .mutation(async ({ input }) => {
        return getClientByAccessCode(input.accessCode);
      }),
  }),

  checkIns: router({
    // Create a new check-in (public with valid client)
    create: publicProcedure
      .input(
        z.object({
          clientId: z.number(),
          accessCode: z.string(),
          responses: z.record(z.string(), z.number()),
          comments: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        // Validate client exists and code matches
        const client = await getClientByAccessCode(input.accessCode);
        if (!client || client.id !== input.clientId) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Código de acceso inválido" });
        }

        const result = await createCheckIn(input.clientId, input.responses, input.comments || "");
        
        // Notify the trainer
        await notifyOwner({
          title: "Nuevo Check-in Recibido",
          content: `${client.name} ha enviado su check-in semanal.`,
        });
        
        return result;
      }),

    // Get all check-ins for a client (admin only)
    listByClient: protectedProcedure
      .input(z.object({ clientId: z.number() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return getCheckInsByClientId(input.clientId);
      }),

    // Get check-in details (admin only)
    getDetail: protectedProcedure
      .input(z.object({ checkInId: z.number() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        const checkIn = await getCheckInById(input.checkInId);
        if (!checkIn) return null;
        const photoList = await getPhotosByCheckInId(input.checkInId);
        return {
          ...checkIn,
          responses: JSON.parse(checkIn.responses),
          photos: photoList,
        };
      }),
  }),

  photos: router({
    // Upload a photo for a check-in (public)
    upload: publicProcedure
      .input(
        z.object({
          checkInId: z.number(),
          fileName: z.string(),
          fileData: z.string(), // base64 encoded
          accessCode: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        // Validate access code
        const client = await getClientByAccessCode(input.accessCode);
        if (!client) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Código de acceso inválido" });
        }

        // Validate file size (max 5MB)
        const buffer = Buffer.from(input.fileData, "base64");
        if (buffer.length > 5 * 1024 * 1024) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Archivo demasiado grande" });
        }

        const storageKey = `check-ins/${input.checkInId}/${Date.now()}-${input.fileName}`;
        const { key, url } = await storagePut(storageKey, buffer, "image/jpeg");
        return createPhoto(input.checkInId, key, url);
      }),

    // Get photos for a check-in (admin only)
    listByCheckIn: protectedProcedure
      .input(z.object({ checkInId: z.number() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return getPhotosByCheckInId(input.checkInId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
