import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function ClientAccess() {
  const [accessCode, setAccessCode] = useState("");
  const [error, setError] = useState("");
  const [, setLocation] = useLocation();
  
  const validateCodeMutation = trpc.clients.getByCode.useMutation({
    onSuccess: (client: any) => {
      if (client) {
        // Store client info in session/localStorage
        sessionStorage.setItem("clientId", client.id.toString());
        sessionStorage.setItem("clientName", client.name);
        sessionStorage.setItem("accessCode", client.accessCode);
        setLocation("/checkin");
      } else {
        setError("Código no válido");
      }
    },
    onError: () => {
      setError("Error al validar el código");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (!accessCode.trim()) {
      setError("Por favor ingresa tu código de acceso");
      return;
    }
    
    validateCodeMutation.mutate({ accessCode: accessCode.trim() });
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4">
      <Card className="w-full max-w-md bg-black border-red-600 border-2">
        <div className="p-8">
          {/* Logo */}
          <div className="mb-8 text-center">
            <img 
              src="/manus-storage/team-mcp-logo_463b88d8.jpeg" 
              alt="TEAM MCP" 
              className="h-24 mx-auto mb-4"
            />
            <h1 className="text-3xl font-bold text-white">TEAM MCP</h1>
            <p className="text-red-600 text-sm mt-2">Check-in Semanal</p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-white font-bold mb-2">
                Ingresa tu código de acceso
              </label>
              <Input
                type="text"
                placeholder="Ej: ABC123"
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value)}
                className="bg-gray-900 border-red-600 text-white placeholder:text-gray-500 focus:border-red-500"
                disabled={validateCodeMutation.isPending}
              />
              {error && (
                <p className="text-red-500 text-sm mt-2">{error}</p>
              )}
            </div>

            <Button
              type="submit"
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2"
              disabled={validateCodeMutation.isPending}
            >
              {validateCodeMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Validando...
                </>
              ) : (
                "Acceder"
              )}
            </Button>
          </form>

          <p className="text-gray-400 text-xs text-center mt-6">
            Si no tienes código de acceso, contacta a tu entrenador
          </p>
        </div>
      </Card>
    </div>
  );
}
