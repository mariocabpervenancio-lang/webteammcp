import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Plus, Trash2, Edit2, Eye } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface ClientWithCheckIns {
  id: number;
  name: string;
  accessCode: string;
  createdAt: Date;
  updatedAt: Date;
  trainerId: number;
}

export default function Dashboard() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedClient, setSelectedClient] = useState<ClientWithCheckIns | null>(null);
  const [selectedCheckIn, setSelectedCheckIn] = useState<any | null>(null);
  const [newClientName, setNewClientName] = useState("");
  const [newClientCode, setNewClientCode] = useState("");
  const [editingClient, setEditingClient] = useState<ClientWithCheckIns | null>(null);
  const [editingName, setEditingName] = useState("");

  // Queries and mutations
  const { data: clients, isLoading: clientsLoading, refetch: refetchClients } = trpc.clients.list.useQuery();
  const { data: checkIns, isLoading: checkInsLoading } = trpc.checkIns.listByClient.useQuery(
    { clientId: selectedClient?.id || 0 },
    { enabled: !!selectedClient }
  );
  const { data: checkInDetail, isLoading: checkInDetailLoading } = trpc.checkIns.getDetail.useQuery(
    { checkInId: selectedCheckIn?.id || 0 },
    { enabled: !!selectedCheckIn }
  );

  const createClientMutation = trpc.clients.create.useMutation({
    onSuccess: () => {
      toast.success("Cliente creado exitosamente");
      setNewClientName("");
      setNewClientCode("");
      refetchClients();
    },
    onError: () => {
      toast.error("Error al crear el cliente");
    },
  });

  const updateClientMutation = trpc.clients.update.useMutation({
    onSuccess: () => {
      toast.success("Cliente actualizado exitosamente");
      setEditingClient(null);
      setEditingName("");
      refetchClients();
    },
    onError: () => {
      toast.error("Error al actualizar el cliente");
    },
  });

  const deleteClientMutation = trpc.clients.delete.useMutation({
    onSuccess: () => {
      toast.success("Cliente eliminado exitosamente");
      setSelectedClient(null);
      refetchClients();
    },
    onError: () => {
      toast.error("Error al eliminar el cliente");
    },
  });

  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) {
      setLocation("/");
    }
  }, [user, loading, setLocation]);

  if (loading || !user || user.role !== "admin") {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-red-600" />
      </div>
    );
  }

  const handleCreateClient = () => {
    if (!newClientName.trim() || !newClientCode.trim()) {
      toast.error("Por favor completa todos los campos");
      return;
    }
    createClientMutation.mutate({
      name: newClientName,
      accessCode: newClientCode,
    });
  };

  const handleUpdateClient = () => {
    if (!editingClient || !editingName.trim()) {
      toast.error("Por favor ingresa un nombre válido");
      return;
    }
    updateClientMutation.mutate({
      clientId: editingClient.id,
      name: editingName,
    });
  };

  const handleDeleteClient = (clientId: number) => {
    if (confirm("¿Estás seguro de que deseas eliminar este cliente?")) {
      deleteClientMutation.mutate({ clientId });
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">TEAM MCP Dashboard</h1>
            <p className="text-gray-400 mt-1">Gestiona tus clientes y check-ins</p>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button className="bg-red-600 hover:bg-red-700 text-white">
                <Plus className="mr-2 h-4 w-4" />
                Nuevo Cliente
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-black border-red-600 border-2">
              <DialogHeader>
                <DialogTitle className="text-white">Crear Nuevo Cliente</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label className="block text-white text-sm font-bold mb-2">Nombre del Cliente</label>
                  <Input
                    value={newClientName}
                    onChange={(e) => setNewClientName(e.target.value)}
                    placeholder="Ej: Juan Pérez"
                    className="bg-gray-900 border-red-600 text-white"
                  />
                </div>
                <div>
                  <label className="block text-white text-sm font-bold mb-2">Código de Acceso</label>
                  <Input
                    value={newClientCode}
                    onChange={(e) => setNewClientCode(e.target.value)}
                    placeholder="Ej: ABC123"
                    className="bg-gray-900 border-red-600 text-white"
                  />
                </div>
                <Button
                  onClick={handleCreateClient}
                  className="w-full bg-red-600 hover:bg-red-700 text-white"
                  disabled={createClientMutation.isPending}
                >
                  {createClientMutation.isPending ? "Creando..." : "Crear Cliente"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Clients List */}
          <div className="lg:col-span-1">
            <Card className="bg-black border-red-600 border-2">
              <div className="p-6">
                <h2 className="text-xl font-bold text-white mb-4">Mis Clientes</h2>
                {clientsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-red-600" />
                  </div>
                ) : clients && clients.length > 0 ? (
                  <div className="space-y-2">
                    {clients.map((client) => (
                      <div
                        key={client.id}
                        onClick={() => setSelectedClient(client)}
                        className={`p-3 rounded cursor-pointer transition ${
                          selectedClient?.id === client.id
                            ? "bg-red-600 text-white"
                            : "bg-gray-900 text-gray-300 hover:bg-gray-800"
                        }`}
                      >
                        <p className="font-bold">{client.name}</p>
                        <p className="text-xs opacity-75">Código: {client.accessCode}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-400 text-sm">No tienes clientes aún</p>
                )}
              </div>
            </Card>
          </div>

          {/* Client Details */}
          <div className="lg:col-span-2">
            {selectedClient ? (
              <div className="space-y-6">
                {/* Client Info Card */}
                <Card className="bg-black border-red-600 border-2">
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h2 className="text-2xl font-bold text-white">{selectedClient.name}</h2>
                        <p className="text-gray-400 text-sm">Código: {selectedClient.accessCode}</p>
                      </div>
                      <div className="flex gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-red-600 text-red-600 hover:bg-red-600 hover:text-white"
                              onClick={() => {
                                setEditingClient(selectedClient);
                                setEditingName(selectedClient.name);
                              }}
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="bg-black border-red-600 border-2">
                            <DialogHeader>
                              <DialogTitle className="text-white">Editar Cliente</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <Input
                                value={editingName}
                                onChange={(e) => setEditingName(e.target.value)}
                                placeholder="Nuevo nombre"
                                className="bg-gray-900 border-red-600 text-white"
                              />
                              <Button
                                onClick={handleUpdateClient}
                                className="w-full bg-red-600 hover:bg-red-700 text-white"
                                disabled={updateClientMutation.isPending}
                              >
                                {updateClientMutation.isPending ? "Actualizando..." : "Actualizar"}
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeleteClient(selectedClient.id)}
                          disabled={deleteClientMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>

                {/* Check-ins List */}
                <Card className="bg-black border-red-600 border-2">
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-4">Check-ins Recientes</h3>
                    {checkInsLoading ? (
                      <div className="flex justify-center py-8">
                        <Loader2 className="h-6 w-6 animate-spin text-red-600" />
                      </div>
                    ) : checkIns && checkIns.length > 0 ? (
                      <div className="space-y-3">
                        {checkIns.map((checkIn: any) => (
                          <div
                            key={checkIn.id}
                            onClick={() => setSelectedCheckIn(checkIn)}
                            className="p-3 bg-gray-900 rounded hover:bg-gray-800 cursor-pointer transition flex items-center justify-between"
                          >
                            <div>
                              <p className="text-white font-bold">
                                {new Date(checkIn.createdAt).toLocaleDateString("es-ES")}
                              </p>
                              <p className="text-gray-400 text-sm">
                                {new Date(checkIn.createdAt).toLocaleTimeString("es-ES")}
                              </p>
                            </div>
                            <Eye className="h-4 w-4 text-red-600" />
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-400 text-sm">No hay check-ins aún</p>
                    )}
                  </div>
                </Card>
              </div>
            ) : (
              <Card className="bg-black border-red-600 border-2">
                <div className="p-12 text-center">
                  <p className="text-gray-400">Selecciona un cliente para ver sus detalles</p>
                </div>
              </Card>
            )}
          </div>
        </div>

        {/* Check-in Detail Modal */}
        {selectedCheckIn && checkInDetail && (
          <Dialog open={!!selectedCheckIn} onOpenChange={() => setSelectedCheckIn(null)}>
            <DialogContent className="bg-black border-red-600 border-2 max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-white">
                  Check-in de {selectedClient?.name}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <div>
                  <p className="text-gray-400 text-sm">
                    {new Date(checkInDetail.createdAt).toLocaleDateString("es-ES", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>

                {/* Responses */}
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-white">Respuestas</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {Object.entries(checkInDetail.responses).map(([key, value]: [string, any]) => (
                      <div key={key} className="bg-gray-900 p-3 rounded">
                        <p className="text-gray-400 text-sm capitalize">{key}</p>
                        <p className="text-red-600 font-bold text-lg">{value}/10</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Comments */}
                {checkInDetail.comments && (
                  <div>
                    <h3 className="text-lg font-bold text-white mb-2">Comentarios</h3>
                    <p className="text-gray-300 bg-gray-900 p-4 rounded">{checkInDetail.comments}</p>
                  </div>
                )}

                {/* Photos */}
                {checkInDetail.photos && checkInDetail.photos.length > 0 && (
                  <div>
                    <h3 className="text-lg font-bold text-white mb-2">Fotos</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {checkInDetail.photos.map((photo: any) => (
                        <img
                          key={photo.id}
                          src={photo.url}
                          alt="Check-in photo"
                          className="w-full h-32 object-cover rounded border-2 border-red-600"
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </DashboardLayout>
  );
}
