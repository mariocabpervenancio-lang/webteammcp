import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Loader2, Upload, X } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface ScaleQuestion {
  key: string;
  label: string;
  emoji: string;
}

const SCALE_QUESTIONS: ScaleQuestion[] = [
  { key: "energy", label: "Nivel de energía general", emoji: "🔥" },
  { key: "fatigue", label: "Nivel de fatiga muscular", emoji: "🔥" },
  { key: "training", label: "Cumplimiento del entrenamiento del día", emoji: "🔥" },
  { key: "intensity", label: "Intensidad percibida durante el entrenamiento", emoji: "🔥" },
  { key: "mindMuscle", label: "Conexión mente-músculo en los ejercicios", emoji: "🔥" },
  { key: "hunger", label: "Hambre o ansiedad entre comidas", emoji: "🔥" },
  { key: "hydration", label: "Hidratación", emoji: "🔥" },
  { key: "sleep", label: "Calidad del sueño", emoji: "🔥" },
  { key: "motivation", label: "Nivel de motivación", emoji: "🔥" },
  { key: "progress", label: "¿Cuánto sientes que avanzaste hoy hacia tu objetivo?", emoji: "🔥" },
];

export default function CheckInForm() {
  const [, setLocation] = useLocation();
  const [clientId, setClientId] = useState<number | null>(null);
  const [clientName, setClientName] = useState("");
  const [accessCode, setAccessCode] = useState("");
  const [responses, setResponses] = useState<Record<string, number>>({});
  const [comments, setComments] = useState("");
  const [photos, setPhotos] = useState<File[]>([]);
  const [photoPreview, setPhotoPreview] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const createCheckInMutation = trpc.checkIns.create.useMutation();
  const uploadPhotoMutation = trpc.photos.upload.useMutation();

  useEffect(() => {
    // Get client info from session
    const id = sessionStorage.getItem("clientId");
    const name = sessionStorage.getItem("clientName");
    const code = sessionStorage.getItem("accessCode");
    
    if (!id || !name || !code) {
      setLocation("/");
      return;
    }
    
    setClientId(parseInt(id));
    setClientName(name);
    setAccessCode(code);

    // Initialize responses with 0 values
    const initialResponses: Record<string, number> = {};
    SCALE_QUESTIONS.forEach((q) => {
      initialResponses[q.key] = 0;
    });
    setResponses(initialResponses);
  }, [setLocation]);

  const handleScaleChange = (key: string, value: number) => {
    setResponses((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const newPhotos = [...photos, ...files].slice(0, 5); // Max 5 photos
    setPhotos(newPhotos);

    // Create previews
    const previews: string[] = [];
    newPhotos.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          previews.push(event.target.result as string);
          if (previews.length === newPhotos.length) {
            setPhotoPreview(previews);
          }
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
    setPhotoPreview((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!clientId) return;

    // Validate all scales are filled
    const allFilled = SCALE_QUESTIONS.every((q) => responses[q.key] > 0);
    if (!allFilled) {
      toast.error("Por favor completa todas las escalas");
      return;
    }

    setIsSubmitting(true);

    try {
      // Create check-in
      const checkInResult = await createCheckInMutation.mutateAsync({
        clientId,
        accessCode,
        responses,
        comments,
      });

      // Upload photos if any
      if (photos.length > 0 && checkInResult) {
        for (const photo of photos) {
          const reader = new FileReader();
          reader.onload = async (event) => {
            if (event.target?.result) {
              const base64 = (event.target.result as string).split(",")[1];
              await uploadPhotoMutation.mutateAsync({
                checkInId: (checkInResult as any).insertId || (checkInResult as any).id || clientId,
                fileName: photo.name,
                fileData: base64,
                accessCode,
              });
            }
          };
          reader.readAsDataURL(photo);
        }
      }

      toast.success("¡Check-in enviado exitosamente!");
      
      // Clear form
      setResponses({});
      setComments("");
      setPhotos([]);
      setPhotoPreview([]);

      // Redirect after 2 seconds
      setTimeout(() => {
        sessionStorage.clear();
        setLocation("/");
      }, 2000);
    } catch (error) {
      toast.error("Error al enviar el check-in");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!clientId) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-red-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-white mb-2">TEAM MCP</h1>
          <p className="text-red-600 font-bold">Check-In Semanal</p>
          <p className="text-gray-400 text-sm mt-2">Hola {clientName}! 👋</p>
        </div>

        {/* Form */}
        <Card className="bg-black border-red-600 border-2">
          <form onSubmit={handleSubmit} className="p-8 space-y-8">
            {/* Scale Questions */}
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-white">
                Rellena este formulario con total sinceridad
              </h2>

              {SCALE_QUESTIONS.map((question) => (
                <div key={question.key} className="space-y-2">
                  <label className="block text-white font-bold text-sm">
                    {question.label} {question.emoji}
                  </label>
                  <div className="flex gap-1 flex-wrap">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => handleScaleChange(question.key, num)}
                        className={`w-10 h-10 rounded font-bold transition-all ${
                          responses[question.key] === num
                            ? "bg-red-600 text-white scale-110"
                            : "bg-gray-800 text-gray-400 hover:bg-gray-700"
                        }`}
                      >
                        {num}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Comments */}
            <div className="space-y-2">
              <label className="block text-white font-bold">
                ¿Quieres comentar algo para que tenga en cuenta al ajustar tu plan?
              </label>
              <Textarea
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                placeholder="Escribe tus comentarios aquí..."
                className="bg-gray-900 border-red-600 text-white placeholder:text-gray-500 min-h-24"
              />
            </div>

            {/* Photo Upload */}
            <div className="space-y-4">
              <label className="block text-white font-bold">
                Fotos de tu estado físico (máximo 5)
              </label>
              
              {/* Photo Preview */}
              {photoPreview.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {photoPreview.map((preview, idx) => (
                    <div key={idx} className="relative">
                      <img
                        src={preview}
                        alt={`Preview ${idx}`}
                        className="w-full h-32 object-cover rounded border-2 border-red-600"
                      />
                      <button
                        type="button"
                        onClick={() => removePhoto(idx)}
                        className="absolute top-1 right-1 bg-red-600 text-white p-1 rounded-full hover:bg-red-700"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Upload Button */}
              {photos.length < 5 && (
                <label className="flex items-center justify-center gap-2 p-6 border-2 border-dashed border-red-600 rounded cursor-pointer hover:bg-gray-900 transition">
                  <Upload className="h-5 w-5 text-red-600" />
                  <span className="text-gray-300">Selecciona fotos</span>
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handlePhotoSelect}
                    className="hidden"
                    disabled={isSubmitting}
                  />
                </label>
              )}
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 text-lg"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Enviando...
                </>
              ) : (
                "Enviar Check-in"
              )}
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
}
